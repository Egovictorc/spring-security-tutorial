package com.victor.Oauthserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OauthAuthorizationApplication {

	public static void main(String[] args) {
		SpringApplication.run(OauthAuthorizationApplication.class, args);
	}

}
